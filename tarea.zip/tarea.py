# TechSolutions S.A.S. — Sistema de Gestión
import uuid

SERVICIOS = {
    "1": ("Desarrollo de Software", 120_000),
    "2": ("Soporte Técnico",         80_000),
    "3": ("Consultoría",            150_000),
    "4": ("Auditoría QA",           100_000),
}

clientes  = {}
contratos = {}

# ── MODELOS ─────────────────────────────────────────────────

class Cliente:
    def __init__(self, nombre, email, empresa=""):
        self.id      = str(uuid.uuid4())[:6].upper()
        self.nombre  = nombre
        self.email   = email
        self.empresa = empresa or "Particular"
    def __str__(self):
        return f"  [{self.id}] {self.nombre} | {self.email} | {self.empresa}"

class Contrato:
    def __init__(self, cliente):
        self.id      = str(uuid.uuid4())[:6].upper()
        self.cliente = cliente
        self.items   = []
    @property
    def subtotal(self): return sum(p*h for _,p,h in self.items)
    @property
    def descuento_pct(self):
        if self.subtotal > 5_000_000: return 10
        if self.subtotal > 2_000_000: return  5
        if len(self.items) > 3:       return  3
        return 0
    @property
    def total(self): return self.subtotal * (1 - self.descuento_pct/100)
    def resumen(self):
        print(f"\n{'═'*52}\n  Contrato #{self.id}  —  {self.cliente.nombre}\n{'─'*52}")
        for n,p,h in self.items:
            print(f"  {n:<26} {h:>4}h × ${p:>9,} = ${p*h:>11,}")
        print(f"{'─'*52}")
        print(f"  Subtotal  : ${self.subtotal:>14,.0f}")
        print(f"  Descuento : {self.descuento_pct}%  (−${self.subtotal*self.descuento_pct/100:>10,.0f})")
        print(f"  TOTAL     : ${self.total:>14,.0f}")
        print("═"*52)

# ── NOTIFICACIONES ───────────────────────────────────────────

def notificar(email, asunto, msg):
    print(f"\n  📧 [EMAIL → {email}] {asunto}: {msg}")

# ── MÓDULO CLIENTES ──────────────────────────────────────────

def registrar_cliente():
    print("\n── Registrar Cliente ──────────────────────────")
    nombre  = input("  Nombre  : ").strip()
    email   = input("  Email   : ").strip()
    empresa = input("  Empresa : ").strip()
    if not nombre or not email:
        print("  ❌ Nombre y email son obligatorios."); return
    c = Cliente(nombre, email, empresa)
    clientes[c.id] = c
    notificar(c.email, "Bienvenido", f"Cuenta creada. Tu ID es {c.id}")
    print(f"\n  ✅ Cliente registrado — ID: {c.id}")

def listar_clientes():
    print("\n── Clientes ────────────────────────────────────")
    if not clientes: print("  (sin clientes)"); return
    for c in clientes.values(): print(c)

def buscar_cliente():
    print("\n── Buscar Cliente ──────────────────────────────")
    id_c = input("  ID cliente: ").strip().upper()
    c = clientes.get(id_c)
    print(c if c else "  ❌ No encontrado.")

def eliminar_cliente():
    listar_clientes()
    if not clientes: return
    id_c = input("\n  ID a eliminar: ").strip().upper()
    if id_c in clientes:
        nombre = clientes[id_c].nombre
        del clientes[id_c]
        print(f"  🗑️  Cliente '{nombre}' eliminado.")
    else:
        print("  ❌ No encontrado.")

# ── MÓDULO SERVICIOS ─────────────────────────────────────────

def _catalogo():
    print(f"\n  {'#':<4} {'Servicio':<28} {'Precio/hora':>12}")
    print("  " + "─"*46)
    for k,(n,p) in SERVICIOS.items():
        print(f"  [{k}] {n:<28} ${p:>10,}")

def crear_contrato():
    listar_clientes()
    if not clientes: return
    id_c = input("\n  ID cliente: ").strip().upper()
    if id_c not in clientes:
        print("  ❌ Cliente no encontrado."); return
    ct = Contrato(clientes[id_c])
    _catalogo()
    while True:
        cod = input("\n  Código (Enter = terminar): ").strip()
        if not cod: break
        if cod not in SERVICIOS: print("  ❌ Código inválido."); continue
        try:
            horas = float(input("  Horas: "))
            if horas <= 0: raise ValueError
        except ValueError:
            print("  ❌ Ingrese un número positivo."); continue
        n, p = SERVICIOS[cod]
        ct.items.append((n, p, horas))
        print(f"  ✅ '{n}' agregado  — Subtotal parcial: ${ct.subtotal:,.0f}")
    if not ct.items:
        print("  ⚠️  Contrato vacío, no se guardó."); return
    contratos[ct.id] = ct
    ct.resumen()
    notificar(clientes[id_c].email, f"Cotización #{ct.id}",
              f"Total: ${ct.total:,.0f} COP  (descuento: {ct.descuento_pct}%)")

def ver_contratos():
    print("\n── Contratos ───────────────────────────────────")
    if not contratos: print("  (sin contratos)"); return
    for c in contratos.values():
        print(f"  #{c.id} | {c.cliente.nombre:<20} | "
              f"Desc {c.descuento_pct:>2}% | Total ${c.total:>12,.0f}")

def ver_contrato_detalle():
    ver_contratos()
    if not contratos: return
    id_ct = input("\n  ID contrato: ").strip().upper()
    ct = contratos.get(id_ct)
    if ct: ct.resumen()
    else: print("  ❌ Contrato no encontrado.")

def eliminar_contrato():
    ver_contratos()
    if not contratos: return
    id_ct = input("\n  ID a eliminar: ").strip().upper()
    if id_ct in contratos:
        del contratos[id_ct]
        print("  🗑️  Contrato eliminado.")
    else:
        print("  ❌ No encontrado.")

# ── MENÚS ────────────────────────────────────────────────────

def menu_clientes():
    opciones = {
        "1": ("Registrar cliente",  registrar_cliente),
        "2": ("Listar clientes",    listar_clientes),
        "3": ("Buscar cliente",     buscar_cliente),
        "4": ("Eliminar cliente",   eliminar_cliente),
    }
    while True:
        print("\n══ CLIENTES ══════════════════════════════════")
        for k,(l,_) in opciones.items(): print(f"  {k}. {l}")
        print("  0. Volver")
        op = input("  Opción: ").strip()
        if op == "0": break
        elif op in opciones: opciones[op][1]()
        else: print("  ⚠️  Inválido.")

def menu_servicios():
    opciones = {
        "1": ("Ver catálogo",           _catalogo),
        "2": ("Crear contrato",         crear_contrato),
        "3": ("Ver todos los contratos",ver_contratos),
        "4": ("Ver contrato detallado", ver_contrato_detalle),
        "5": ("Eliminar contrato",      eliminar_contrato),
    }
    while True:
        print("\n══ SERVICIOS & CONTRATOS ═════════════════════")
        for k,(l,_) in opciones.items(): print(f"  {k}. {l}")
        print("  0. Volver")
        op = input("  Opción: ").strip()
        if op == "0": break
        elif op in opciones: opciones[op][1]()
        else: print("  ⚠️  Inválido.")

def main():
    print("\n" + "═"*52)
    print("   TechSolutions S.A.S. — Sistema de Gestión v2")
    print("═"*52)
    MENU = {
        "1": ("Gestión de Clientes",           menu_clientes),
        "2": ("Gestión de Servicios",          menu_servicios),
    }
    while True:
        print(f"\n── MENÚ PRINCIPAL {'─'*26}")
        print(f"  Clientes: {len(clientes)}  |  Contratos: {len(contratos)}")
        print("─"*44)
        for k,(l,_) in MENU.items(): print(f"  {k}. {l}")
        print("  0. Salir")
        op = input("  Opción: ").strip()
        if op == "0": print("\n  👋 Hasta luego.\n"); break
        elif op in MENU: MENU[op][1]()
        else: print("  ⚠️  Inválido.")

if __name__ == "__main__":
    main()